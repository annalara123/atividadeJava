import model.GerenciadorCarrinho;

public class Main {
    public static void main(String[] args) {
        GerenciadorCarrinho gerenciador = new GerenciadorCarrinho();
        gerenciador.iniciarSistema();
    }
}
